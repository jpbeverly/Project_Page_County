##' Four short time series
##'
##' Four short times series, stored in a list, for use in the \code{\link{timeDiff}} example.
##'
##' @name timeDiff.eg
##' @docType data
##' @keywords datasets
##' @examples
##'
##' data(timeDiff.eg)
##'
NULL
